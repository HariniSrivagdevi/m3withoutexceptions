package com.cg.ShareTrading.Beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class Stock {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqId")
    @SequenceGenerator(name="seqId", initialValue=50, allocationSize=1, sequenceName = "stock_id")
    @Column(name="id", updatable=false, nullable=false)
	private int id;
	private String name;
	@Min(500)
	@Max(50000)
	private double price;
	private int quantity;
	private double amount;
	private double brokerage;
	
	public Stock() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Stock(int id, String name, double price, int quantity, double amount, double brokerage) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.amount = amount;
		this.brokerage = brokerage;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(double brokerage) {
		this.brokerage = brokerage;
	}

	@Override
	public String toString() {
		return "Stock [id=" + id + ", name=" + name + ", price=" + price + ", quantity=" + quantity + ", amount="
				+ amount + ", brokerage=" + brokerage + "]";
	}

}
