package com.cg.ShareTrading.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ShareTrading.Beans.Stock;
import com.cg.ShareTrading.Service.StockService;

@RestController
public class StockController {
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="stock id is not found")
	@ExceptionHandler({Exception.class})
	public void handleException() {
		
	}

	@Autowired
	StockService stockService;
	
	@RequestMapping("/calculateOrder")
	public int calculateOrder(Stock stock) {
		return stockService.calculateOrder(stock);
	}

	@RequestMapping("/getAllStocks")
	public List<Stock> getAllStocks() {
		return stockService.getAllStocks();
	}
	
	@RequestMapping(value="/addStocks",method=RequestMethod.POST)
	public List<Stock> addStocks(@RequestBody Stock stock) {
		return stockService.addStocks(stock);
	}
	
	@RequestMapping("/getStockById/{id}")
	public Stock getStockById(@PathVariable int id) {
		return stockService.getStockById(id);
   }
	
	@DeleteMapping("/deleteStockById/{id}")
	public ResponseEntity<String> deleteStockById(@PathVariable int id) {
		stockService.deleteStockById(id);
		return new ResponseEntity<String>("Stock with id " +id+ " deleted", HttpStatus.OK);
	}
	
	@PutMapping("/updateStock/{id}")
	public List<Stock> updateStock(@PathVariable int id,@RequestBody Stock stock) {
		return stockService.updateStock(id,stock);
	}
}
