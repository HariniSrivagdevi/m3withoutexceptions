package com.cg.ShareTrading.Service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ShareTrading.Beans.Stock;
import com.cg.ShareTrading.Dao.StockDao;


@Service
public class StockServiceImpl implements StockService {

	@Autowired
	StockDao stockDao;
	
	@Override
	public int calculateOrder(Stock bean) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Stock> getAllStocks() {
		// TODO Auto-generated method stub
		return stockDao.findAll();
	}

	@Override
	public List<Stock> addStocks(Stock stock) {
		// TODO Auto-generated method stub
		double amount=stock.getPrice()*stock.getQuantity();
	    stock.setAmount(amount);
	    stockDao.save(stock);
	    double brokerage=(amount*0.5)/100;
	    stock.setBrokerage(brokerage);
	    stockDao.save(stock);
		return stockDao.findAll();
	}

	@Override
	public Stock getStockById(int id) {
		// TODO Auto-generated method stub
		return stockDao.findById(id).get();
	}

	@Override
	public void deleteStockById(int id) {
		// TODO Auto-generated method stub
		stockDao.deleteById(id);
		
	}

	@Override
	public List<Stock> updateStock(int id, Stock stock) {
		// TODO Auto-generated method stub
		Optional<Stock> optional=stockDao.findById(id);
		{
			Stock sto=optional.get();
			sto.setName(stock.getName());
			sto.setPrice(stock.getPrice());
			/*sto.setBrokerage(stock.getBrokerage());*/
			sto.setQuantity(stock.getQuantity());
			
			double amount=stock.getPrice()*stock.getQuantity();
		    stock.setAmount(amount);
		    stockDao.save(stock);
		    double brokerage=(amount*0.5)/100;
		    stock.setBrokerage(brokerage);
		    stockDao.save(stock);
		    return getAllStocks();
	}

	}
	}
