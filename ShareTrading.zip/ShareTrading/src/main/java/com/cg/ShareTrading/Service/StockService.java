package com.cg.ShareTrading.Service;

import java.util.List;

import javax.validation.Valid;

import com.cg.ShareTrading.Beans.Stock;

public interface StockService {

	public int calculateOrder(Stock bean);

	public List<Stock> getAllStocks();

	public List<Stock> addStocks(Stock stock);

	public Stock getStockById(int id);

	public void deleteStockById(int id);

	public List<Stock> updateStock(int id, Stock stock);
	
}
