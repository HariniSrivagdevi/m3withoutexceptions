package com.cg.ShareTrading.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ShareTrading.Beans.Stock;


@Repository
public interface StockDao extends JpaRepository<Stock,Integer>{

	/*int saveOrder(Stock bean);*/
	
	@Query("from Stock where id=:d")
	Optional<Stock> findById(@Param("d") int id);
}
